import subprocess
def main():
    result = subprocess.check_output('python simulation.py')
    out_list = result.decode("utf-8").split()
    new_list = list(map(int, out_list))
    print("[num_saercher_eaten, num_lost_unfound, successful?")
    print(new_list)

if __name__ == '__main__':
    main()